from __future__ import annotations

import base64
import datetime
import decimal
import hashlib
import hmac as _hmac_module
import json
import math
import re
import secrets
import struct
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable, Literal

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

HmacAlgorithmV2 = Literal["SHA-256", "SHA-384", "SHA-512"]
# Counter encoding in the KDF password; 'string' is for compatibility with V1.
CounterModeV2 = Literal["uint32", "string"]

DEFAULT_KEY_LENGTH: int = 32
DEFAULT_KEY_PREFIX: str = "00"
DEFAULT_HMAC_ALGORITHM: HmacAlgorithmV2 = "SHA-256"
DEFAULT_COUNTER_MODE: CounterModeV2 = "uint32"

DeriveKeyFunctionV2 = Callable[["ChallengeParameters", bytes, bytes], bytes]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

# Optional parameter keys (camelCase) and their attribute names.
_OPTIONAL_PARAMETERS = {
    "keySignature": "key_signature",
    "memoryCost": "memory_cost",
    "parallelism": "parallelism",
    "expiresAt": "expires_at",
    "data": "data",
}


class ChallengeParameters:
    """
    Parameters embedded in a v2 challenge.

    Attributes:
        algorithm: Key derivation algorithm (e.g. 'PBKDF2/SHA-256', 'ARGON2ID', 'SCRYPT', 'SHA-256').
        nonce: Random 16-byte hex string used as the KDF password prefix.
        salt: Random 16-byte hex string used as the KDF salt.
        cost: Algorithm-specific cost parameter (iterations / time cost).
        key_length: Derived key length in bytes. Defaults to 32.
        key_prefix: Hex prefix the derived key must start with to solve the challenge.
        key_signature: Optional HMAC of the derived key for fast server-side verification.
        memory_cost: Memory cost in KiB (Argon2id / scrypt only).
        parallelism: Parallelism factor (Argon2id / scrypt only).
        expires_at: Unix timestamp (seconds) after which the challenge is invalid.
        data: Arbitrary metadata embedded in the challenge.
    """

    # Optional keys received as explicit JSON null; kept so the signed JSON matches
    # issuers (altcha-lib) that sign them as null. Set on the instance by from_dict
    # only when present, so __dict__ holds just the constructor arguments.
    _explicit_nulls: frozenset[str] = frozenset()

    def __init__(
        self,
        algorithm: str,
        nonce: str,
        salt: str,
        cost: int,
        key_length: int = DEFAULT_KEY_LENGTH,
        key_prefix: str = DEFAULT_KEY_PREFIX,
        key_signature: str | None = None,
        memory_cost: int | None = None,
        parallelism: int | None = None,
        expires_at: int | None = None,
        data: dict | None = None,
    ):
        self.algorithm = algorithm
        self.nonce = nonce
        self.salt = salt
        self.cost = cost
        self.key_length = key_length
        self.key_prefix = key_prefix
        self.key_signature = key_signature
        self.memory_cost = memory_cost
        self.parallelism = parallelism
        self.expires_at = expires_at
        self.data = data

    def to_dict(self) -> dict:
        """Return a camelCase dict suitable for JSON serialization / signing."""
        d: dict = {
            "algorithm": self.algorithm,
            "cost": self.cost,
            "keyLength": self.key_length,
            "keyPrefix": self.key_prefix,
            "nonce": self.nonce,
            "salt": self.salt,
        }
        for key, attr in _OPTIONAL_PARAMETERS.items():
            value = getattr(self, attr)
            if value is not None or key in self._explicit_nulls:
                d[key] = value
        return d

    @classmethod
    def from_dict(cls, d: dict) -> ChallengeParameters:
        params = cls(
            algorithm=d["algorithm"],
            nonce=d["nonce"],
            salt=d["salt"],
            cost=d["cost"],
            key_length=d.get("keyLength", DEFAULT_KEY_LENGTH),
            key_prefix=d.get("keyPrefix", DEFAULT_KEY_PREFIX),
            key_signature=d.get("keySignature"),
            memory_cost=d.get("memoryCost"),
            parallelism=d.get("parallelism"),
            expires_at=d.get("expiresAt"),
            data=d.get("data"),
        )
        explicit_nulls = frozenset(
            key for key in _OPTIONAL_PARAMETERS if key in d and d[key] is None
        )
        if explicit_nulls:
            params._explicit_nulls = explicit_nulls
        return params


class Challenge:
    """
    A v2 proof-of-work challenge sent to the client.

    Attributes:
        parameters: The KDF parameters the client must solve.
        signature: HMAC of the canonical JSON of parameters (prevents tampering).
    """

    def __init__(
        self,
        parameters: ChallengeParameters,
        signature: str | None = None,
    ):
        self.parameters = parameters
        self.signature = signature

    def to_dict(self) -> dict:
        d: dict = {"parameters": self.parameters.to_dict()}
        if self.signature is not None:
            d["signature"] = self.signature
        return d

    @classmethod
    def from_dict(cls, d: dict) -> Challenge:
        return cls(
            parameters=ChallengeParameters.from_dict(d["parameters"]),
            signature=d.get("signature"),
        )


class Solution:
    """
    A v2 challenge solution found by the client.

    Attributes:
        counter: The counter value that produced a matching derived key.
        derived_key: Hex-encoded derived key.
        time: Time taken to solve in milliseconds (optional).
    """

    def __init__(self, counter: int, derived_key: str, time: float | None = None):
        self.counter = counter
        self.derived_key = derived_key
        self.time = time

    def to_dict(self) -> dict:
        d: dict = {"counter": self.counter, "derivedKey": self.derived_key}
        if self.time is not None:
            d["time"] = self.time
        return d

    @classmethod
    def from_dict(cls, d: dict) -> Solution:
        return cls(
            counter=d["counter"],
            derived_key=d["derivedKey"],
            time=d.get("time"),
        )


class Payload:
    """
    A complete v2 payload (challenge + solution) transmitted from the client.

    Attributes:
        challenge: The challenge that was solved.
        solution: The solution found by the client.
    """

    def __init__(self, challenge: Challenge, solution: Solution):
        self.challenge = challenge
        self.solution = solution

    def to_dict(self) -> dict:
        return {
            "challenge": self.challenge.to_dict(),
            "solution": self.solution.to_dict(),
        }

    def to_base64(self) -> str:
        return base64.b64encode(json.dumps(self.to_dict()).encode()).decode()

    @classmethod
    def from_dict(cls, d: dict) -> Payload:
        return cls(
            challenge=Challenge.from_dict(d["challenge"]),
            solution=Solution.from_dict(d["solution"]),
        )

    @classmethod
    def from_base64(cls, data: str) -> Payload:
        return cls.from_dict(json.loads(base64.b64decode(data).decode()))


class VerifySolutionResult:
    """
    The result of a v2 solution verification.

    Attributes:
        expired: True if the challenge has expired.
        invalid_signature: True if the challenge signature is missing or invalid.
        invalid_solution: True if the solution is incorrect.
        time: Time taken for verification in milliseconds.
        verified: True if the solution is valid.
        error: Human-readable error message if parsing failed.
    """

    def __init__(
        self,
        expired: bool,
        invalid_signature: bool | None,
        invalid_solution: bool | None,
        time: float,
        verified: bool,
        error: str | None = None,
    ):
        self.expired = expired
        self.invalid_signature = invalid_signature
        self.invalid_solution = invalid_solution
        self.time = time
        self.verified = verified
        self.error = error


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _make_password(
    nonce: bytes, counter: int, counter_mode: CounterModeV2 = DEFAULT_COUNTER_MODE
) -> bytes:
    """Combine nonce and counter into a KDF password buffer.

    ``'uint32'`` appends the counter as a big-endian uint32; ``'string'`` appends its
    decimal digits.
    """
    if counter_mode == "string":
        return nonce + str(counter).encode()
    return nonce + struct.pack(">I", counter)


def _buffer_starts_with(buf: bytes, prefix: bytes) -> bool:
    if len(prefix) > len(buf):
        return False
    return buf[: len(prefix)] == prefix


_HEX_RE = re.compile(r"(?:[0-9a-fA-F]{2})*")


def _hex_to_bytes(value: object) -> bytes | None:
    """Decode an even-length hex string; ``None`` for non-strings or malformed hex."""
    if not isinstance(value, str) or _HEX_RE.fullmatch(value) is None:
        return None
    return bytes.fromhex(value)


_JSON_ESCAPE_RE = re.compile(r'[\x00-\x1f"\\\ud800-\udfff]')
_JSON_ESCAPES = {
    '"': '\\"',
    "\\": "\\\\",
    "\b": "\\b",
    "\f": "\\f",
    "\n": "\\n",
    "\r": "\\r",
    "\t": "\\t",
}
_ARRAY_INDEX_RE = re.compile(r"0|[1-9][0-9]*")
_MAX_ARRAY_INDEX = 2**32 - 2
_MAX_SAFE_INTEGER = 2**53


def _js_string(s: str) -> str:
    """``JSON.stringify`` of a string: JS escapes, lone surrogates as ``\\uXXXX``."""
    # Re-pair surrogate halves so only lone surrogates remain as surrogate chars.
    s = s.encode("utf-16-le", "surrogatepass").decode("utf-16-le", "surrogatepass")
    escaped = _JSON_ESCAPE_RE.sub(
        lambda m: _JSON_ESCAPES.get(m[0], f"\\u{ord(m[0]):04x}"), s
    )
    return f'"{escaped}"'


def _js_number(x: float) -> str:
    """``JSON.stringify`` of a number: IEEE-754 double, ECMAScript ``Number::toString``."""
    if isinstance(x, int):
        if -_MAX_SAFE_INTEGER <= x <= _MAX_SAFE_INTEGER:
            # int.__repr__ like json.dumps: subclasses (IntEnum) may override str().
            return int.__repr__(x)
        try:
            x = float(x)
        except OverflowError:
            return "null"
    if not math.isfinite(x):
        return "null"
    if x == 0:
        return "0"
    # repr() yields the shortest round-tripping digits, as JS does.
    sign, digit_tuple, exp = decimal.Decimal(float.__repr__(x)).as_tuple()
    assert isinstance(exp, int)
    padded = "".join(map(str, digit_tuple))
    digits = padded.rstrip("0")
    k = len(digits)
    n = exp + len(padded)  # value = 0.digits * 10**n
    if k <= n <= 21:
        out = digits + "0" * (n - k)
    elif 0 < n <= 21:
        out = f"{digits[:n]}.{digits[n:]}"
    elif -6 < n <= 0:
        out = "0." + "0" * -n + digits
    else:
        mantissa = f"{digits[0]}.{digits[1:]}" if k > 1 else digits
        out = f"{mantissa}e{'+' if n > 0 else '-'}{abs(n - 1)}"
    return f"-{out}" if sign else out


def _js_key(key: object) -> str:
    """Coerce a dict key the way ``json.dumps`` does when the payload is sent."""
    if isinstance(key, str):
        return key
    if key is None or isinstance(key, (int, float)):
        return json.dumps(key)
    raise TypeError(
        f"keys must be str, int, float, bool or None, not {type(key).__name__}"
    )


def _is_array_index(key: str) -> bool:
    return _ARRAY_INDEX_RE.fullmatch(key) is not None and int(key) <= _MAX_ARRAY_INDEX


def _js_json(value: object, sort: bool) -> str:
    """``JSON.stringify(sortKeys(value))`` (when *sort*) or ``JSON.stringify(value)``.

    JS objects enumerate array-index keys first in numeric order, then the other
    keys in insertion order; ``sortKeys`` inserts them sorted by UTF-16 code units.
    ``sortKeys`` does not descend into arrays.

    Raises:
        ValueError: On a ``__proto__`` key at a sorted level. ``sortKeys`` assigns it
            through the prototype setter, so JS leaves it unsigned; rejected instead.
    """
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return _js_string(value)
    if isinstance(value, (int, float)):
        return _js_number(value)
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(_js_json(item, False) for item in value) + "]"
    if isinstance(value, dict):
        items = {_js_key(k): v for k, v in value.items()}
        index_keys = sorted((k for k in items if _is_array_index(k)), key=int)
        other_keys = [k for k in items if not _is_array_index(k)]
        if sort:
            if "__proto__" in items:
                raise ValueError("'__proto__' keys cannot be signed")
            other_keys.sort(key=lambda k: k.encode("utf-16-be", "surrogatepass"))
        return (
            "{"
            + ",".join(
                f"{_js_string(k)}:{_js_json(items[k], sort)}"
                for k in index_keys + other_keys
            )
            + "}"
        )
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def _canonical_json(obj: dict) -> str:
    """Canonical JSON for signing; byte-identical to altcha-lib's ``canonicalJSON``."""
    return _js_json(obj, True)


def _hmac_v2(algorithm: str, data: str | bytes, key: str | bytes) -> bytes:
    """Compute HMAC and return raw bytes."""
    if isinstance(data, str):
        data = data.encode()
    if isinstance(key, str):
        key = key.encode()
    hash_name = algorithm.lower().replace("-", "")  # 'sha256', 'sha384', 'sha512'
    return _hmac_module.new(key, data, getattr(hashlib, hash_name)).digest()


def _constant_time_equal(a: object, b: object) -> bool:
    """Constant-time string comparison; ``False`` if either side is not a string."""
    if not isinstance(a, str) or not isinstance(b, str):
        return False
    return _hmac_module.compare_digest(
        a.encode("utf-8", "surrogatepass"), b.encode("utf-8", "surrogatepass")
    )


def _sign_challenge_v2(
    hmac_algorithm: str,
    parameters: ChallengeParameters,
    derived_key: bytes | None,
    hmac_secret: str | bytes,
    hmac_key_secret: str | bytes | None = None,
) -> Challenge:
    """Sign challenge parameters with HMAC, optionally also signing the derived key."""
    if derived_key is not None and hmac_key_secret:
        parameters.key_signature = _hmac_v2(
            hmac_algorithm, derived_key, hmac_key_secret
        ).hex()

    params_dict = parameters.to_dict()
    canonical = _canonical_json(params_dict)
    signature = _hmac_v2(hmac_algorithm, canonical, hmac_secret).hex()
    return Challenge(parameters=parameters, signature=signature)


# ---------------------------------------------------------------------------
# Key derivation algorithms
# ---------------------------------------------------------------------------


# Exact-match lookups with a sha256 fallback, as in altcha-lib's getDigest.
_SHA_DIGESTS = {"SHA-512": "sha512", "SHA-384": "sha384"}
_PBKDF2_DIGESTS = {"PBKDF2/SHA-512": "sha512", "PBKDF2/SHA-384": "sha384"}


def _sha_digest(algorithm: str) -> str:
    """Map algorithm string to hashlib name; unrecognized values use ``'sha256'``."""
    return _SHA_DIGESTS.get(algorithm, "sha256")


def _pbkdf2_digest(algorithm: str) -> str:
    """Map PBKDF2 algorithm string to hashlib name; unrecognized values use ``'sha256'``."""
    return _PBKDF2_DIGESTS.get(algorithm, "sha256")


def derive_key_sha(
    parameters: ChallengeParameters, salt: bytes, password: bytes
) -> bytes:
    """
    Iterated SHA key derivation (mirrors the JS sha.ts algorithm).

    Performs ``cost`` iterations of hashing, starting with ``salt + password``,
    then feeding the previous hash into the next round. 'SHA-384' and 'SHA-512'
    select those digests; any other algorithm uses SHA-256.
    """
    algo = _sha_digest(parameters.algorithm)
    iterations = max(1, parameters.cost)
    data = salt + password
    derived: bytes = b""
    for i in range(iterations):
        if i > 0:
            data = derived
        derived = hashlib.new(algo, data).digest()
    return derived[: parameters.key_length]


def derive_key_pbkdf2(
    parameters: ChallengeParameters, salt: bytes, password: bytes
) -> bytes:
    """PBKDF2 key derivation. 'PBKDF2/SHA-384' and 'PBKDF2/SHA-512' select those digests;
    any other algorithm uses SHA-256."""
    digest = _pbkdf2_digest(parameters.algorithm)
    return hashlib.pbkdf2_hmac(
        digest, password, salt, parameters.cost, parameters.key_length
    )


def derive_key_scrypt(
    parameters: ChallengeParameters, salt: bytes, password: bytes
) -> bytes:
    """
    Scrypt key derivation.

    Parameters map as: ``cost`` → N, ``memory_cost`` → r (block size),
    ``parallelism`` → p.
    """
    n = parameters.cost
    r = parameters.memory_cost or 8
    p = parameters.parallelism or 1
    maxmem = 2 * 128 * n * r
    return hashlib.scrypt(
        password, salt=salt, n=n, r=r, p=p, dklen=parameters.key_length, maxmem=maxmem
    )


try:
    from argon2.low_level import (  # type: ignore
        Type as _Argon2Type,
        hash_secret_raw as _argon2_hash_secret_raw,
    )

    def derive_key_argon2id(
        parameters: ChallengeParameters, salt: bytes, password: bytes
    ) -> bytes:
        """Argon2id key derivation. Requires the ``argon2-cffi`` package."""
        return _argon2_hash_secret_raw(
            secret=password,
            salt=salt,
            time_cost=parameters.cost,
            memory_cost=parameters.memory_cost or 65536,
            parallelism=parameters.parallelism or 1,
            hash_len=parameters.key_length,
            type=_Argon2Type.ID,
        )

except ImportError:

    def derive_key_argon2id(  # type: ignore[misc]
        parameters: ChallengeParameters, salt: bytes, password: bytes
    ) -> bytes:
        """Argon2id key derivation (unavailable — install ``argon2-cffi``)."""
        raise ImportError(
            "argon2-cffi is required for Argon2id. Install with: pip install argon2-cffi"
        )


def _select_derive_key(algorithm: str) -> DeriveKeyFunctionV2:
    """Return the appropriate built-in derive_key function for the given algorithm string."""
    alg = algorithm.upper()
    if alg.startswith("PBKDF2"):
        return derive_key_pbkdf2
    if alg == "ARGON2ID":
        return derive_key_argon2id
    if alg == "SCRYPT":
        return derive_key_scrypt
    # Fallback: plain iterated SHA (algorithm is e.g. 'SHA-256')
    return derive_key_sha


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def create_challenge(
    algorithm: str,
    cost: int,
    *,
    derive_key: DeriveKeyFunctionV2 | None = None,
    counter: int | None = None,
    counter_mode: CounterModeV2 = DEFAULT_COUNTER_MODE,
    key_length: int = DEFAULT_KEY_LENGTH,
    key_prefix: str = DEFAULT_KEY_PREFIX,
    key_prefix_length: int | None = None,
    memory_cost: int | None = None,
    parallelism: int | None = None,
    expires_at: int | datetime.datetime | None = None,
    data: dict | None = None,
    hmac_secret: str | bytes | None = None,
    hmac_key_secret: str | bytes | None = None,
    hmac_algorithm: HmacAlgorithmV2 = DEFAULT_HMAC_ALGORITHM,
) -> Challenge:
    """
    Create a new v2 proof-of-work challenge.

    Args:
        algorithm: KDF algorithm identifier (e.g. ``'PBKDF2/SHA-256'``, ``'ARGON2ID'``, ``'SCRYPT'``).
        cost: Algorithm-specific cost parameter (iterations, passes, …).
        derive_key: KDF function ``(parameters, salt, password) -> bytes``.
            Defaults to the built-in function selected by *algorithm*.
        counter: If given, pre-solve with this counter and embed the resulting key prefix
            so the client must find this exact counter (deterministic mode).
        counter_mode: Counter encoding in the KDF password: ``'uint32'`` (default) or
            ``'string'`` (V1 compatibility). Solver and verifier must use the same mode.
        key_length: Derived key length in bytes. Defaults to 32.
        key_prefix: Hex prefix the derived key must start with; stored lowercased.
            Defaults to ``'00'``.
        key_prefix_length: Bytes of the derived key used as prefix in deterministic mode.
            Defaults to ``key_length // 2``.
        memory_cost: Memory cost in KiB (Argon2id / scrypt).
        parallelism: Parallelism factor (Argon2id / scrypt).
        expires_at: Expiry as a Unix timestamp (int) or ``datetime``.
        data: Arbitrary metadata to embed in the challenge parameters. Dict keys
            named ``'__proto__'`` (outside arrays) cannot be signed.
        hmac_secret: Secret used to HMAC-sign the challenge parameters.
            If omitted or empty, the challenge is unsigned.
        hmac_key_secret: If set and non-empty, also HMAC the derived key for fast
            verification.
        hmac_algorithm: HMAC digest algorithm. Defaults to ``'SHA-256'``.

    Returns:
        A :class:`Challenge` instance.

    Raises:
        ValueError: If signing and *data* contains a ``'__proto__'`` key.
    """
    if derive_key is None:
        derive_key = _select_derive_key(algorithm)

    if key_prefix_length is None:
        key_prefix_length = key_length // 2

    expires_at_ts: int | None = None
    if expires_at is not None:
        if isinstance(expires_at, datetime.datetime):
            expires_at_ts = int(expires_at.timestamp())
        else:
            expires_at_ts = int(expires_at)

    nonce = secrets.token_bytes(16).hex()
    salt = secrets.token_bytes(16).hex()

    parameters = ChallengeParameters(
        algorithm=algorithm,
        nonce=nonce,
        salt=salt,
        cost=cost,
        key_length=key_length,
        key_prefix=key_prefix.lower(),
        memory_cost=memory_cost,
        parallelism=parallelism,
        expires_at=expires_at_ts,
        data=data,
    )

    derived_key_bytes: bytes | None = None
    if counter is not None:
        nonce_bytes = bytes.fromhex(nonce)
        salt_bytes = bytes.fromhex(salt)
        password = _make_password(nonce_bytes, counter, counter_mode)
        derived_key_bytes = derive_key(parameters, salt_bytes, password)
        parameters.key_prefix = derived_key_bytes[:key_prefix_length].hex()

    if not hmac_secret:
        return Challenge(parameters=parameters, signature=None)

    return _sign_challenge_v2(
        hmac_algorithm, parameters, derived_key_bytes, hmac_secret, hmac_key_secret
    )


def solve_challenge(
    challenge: Challenge,
    derive_key: DeriveKeyFunctionV2 | None = None,
    *,
    counter_start: int = 0,
    counter_step: int = 1,
    timeout: float = 90.0,
    counter_mode: CounterModeV2 = DEFAULT_COUNTER_MODE,
) -> Solution | None:
    """
    Solve a v2 challenge by brute-forcing counter values.

    Args:
        challenge: The challenge to solve.
        derive_key: KDF function. Defaults to the built-in selected by the challenge algorithm.
        counter_start: First counter value to try.
        counter_step: Increment between attempts. Use > 1 for parallel partitioning.
        timeout: Maximum seconds to spend. Returns ``None`` on timeout.
        counter_mode: Counter encoding in the KDF password: ``'uint32'`` (default) or
            ``'string'``. Must match the mode used by the issuer.

    Returns:
        A :class:`Solution` on success, or ``None`` if no solution was found in time.
    """
    params = challenge.parameters
    if derive_key is None:
        derive_key = _select_derive_key(params.algorithm)

    nonce_bytes = bytes.fromhex(params.nonce)
    salt_bytes = bytes.fromhex(params.salt)

    key_prefix = params.key_prefix.lower()
    prefix_bytes: bytes | None = (
        bytes.fromhex(key_prefix) if len(key_prefix) % 2 == 0 else None
    )

    start_time = time.monotonic()
    counter = counter_start

    while True:
        if timeout and (time.monotonic() - start_time) > timeout:
            return None

        password = _make_password(nonce_bytes, counter, counter_mode)
        derived_key = derive_key(params, salt_bytes, password)

        matched = (
            _buffer_starts_with(derived_key, prefix_bytes)
            if prefix_bytes is not None
            else derived_key.hex().startswith(key_prefix)
        )

        if matched:
            return Solution(
                counter=counter,
                derived_key=derived_key.hex(),
                time=(time.monotonic() - start_time) * 1000,
            )

        counter += counter_step


def verify_solution(
    payload: str | Payload,
    hmac_secret: str | bytes,
    derive_key: DeriveKeyFunctionV2 | None = None,
    *,
    hmac_key_secret: str | bytes | None = None,
    hmac_algorithm: HmacAlgorithmV2 = DEFAULT_HMAC_ALGORITHM,
    counter_mode: CounterModeV2 = DEFAULT_COUNTER_MODE,
) -> VerifySolutionResult:
    """
    Verify a v2 challenge solution.

    Checks (in order):

    1. Whether the challenge has expired.
    2. Whether the challenge signature is present.
    3. Whether the challenge signature is valid (tamper check).
    4. Whether the solution is correct — via key signature (fast) or re-derivation (slow).

    Args:
        payload: Base64-encoded JSON payload string or a :class:`Payload` object.
        hmac_secret: Secret used to verify the challenge signature. Must not be empty.
        derive_key: KDF function for re-derivation. Defaults to built-in for the algorithm.
        hmac_key_secret: Secret used to verify the derived-key signature (fast path).
        hmac_algorithm: HMAC digest algorithm. Defaults to ``'SHA-256'``.
        counter_mode: Counter encoding used when re-deriving the key: ``'uint32'``
            (default) or ``'string'``. Must match the mode used by the issuer.

    Returns:
        A :class:`VerifySolutionResult` describing the outcome.

    Raises:
        ValueError: If *hmac_secret* is empty.
    """
    if not hmac_secret:
        raise ValueError("hmac_secret must not be empty")
    start_time = time.monotonic()

    challenge: Challenge
    solution: Solution

    if isinstance(payload, str):
        try:
            d = json.loads(base64.b64decode(payload).decode())
            challenge = Challenge.from_dict(d["challenge"])
            solution = Solution.from_dict(d["solution"])
        except (ValueError, KeyError, TypeError, RecursionError):
            return VerifySolutionResult(
                expired=False,
                invalid_signature=None,
                invalid_solution=None,
                time=(time.monotonic() - start_time) * 1000,
                verified=False,
                error="Invalid altcha payload",
            )
    else:
        challenge = payload.challenge
        solution = payload.solution

    # 1. Expiration check.
    # Non-numeric values are left to the signature check, which rejects them
    # unless the server signed them.
    expires_at = challenge.parameters.expires_at
    if isinstance(expires_at, (int, float)) and expires_at and expires_at < time.time():
        return VerifySolutionResult(
            expired=True,
            invalid_signature=None,
            invalid_solution=None,
            time=(time.monotonic() - start_time) * 1000,
            verified=False,
        )

    # 2. Signature must be present.
    if not challenge.signature:
        return VerifySolutionResult(
            expired=False,
            invalid_signature=True,
            invalid_solution=None,
            time=(time.monotonic() - start_time) * 1000,
            verified=False,
        )

    # 3. Verify challenge signature (tamper check). Data that cannot be serialized
    # (nested too deeply, '__proto__' keys) cannot carry a valid signature.
    try:
        canonical = _canonical_json(challenge.parameters.to_dict())
    except (RecursionError, ValueError):
        canonical = None
    if canonical is None or not _constant_time_equal(
        challenge.signature, _hmac_v2(hmac_algorithm, canonical, hmac_secret).hex()
    ):
        return VerifySolutionResult(
            expired=False,
            invalid_signature=True,
            invalid_solution=None,
            time=(time.monotonic() - start_time) * 1000,
            verified=False,
        )

    params = challenge.parameters

    # 4a. Fast path: verify derived key via its HMAC signature.
    if params.key_signature and hmac_key_secret:
        derived_key_bytes = _hex_to_bytes(solution.derived_key)
        valid = derived_key_bytes is not None and _constant_time_equal(
            params.key_signature,
            _hmac_v2(hmac_algorithm, derived_key_bytes, hmac_key_secret).hex(),
        )
        return VerifySolutionResult(
            expired=False,
            invalid_signature=False,
            invalid_solution=not valid,
            time=(time.monotonic() - start_time) * 1000,
            verified=valid,
        )

    # 4b. Slow path: re-derive the key from the counter and compare, and
    # require it to satisfy the signed key prefix.
    counter = solution.counter
    if type(counter) is not int or not 0 <= counter <= 0xFFFFFFFF:
        return VerifySolutionResult(
            expired=False,
            invalid_signature=False,
            invalid_solution=True,
            time=(time.monotonic() - start_time) * 1000,
            verified=False,
        )

    if derive_key is None:
        derive_key = _select_derive_key(params.algorithm)

    nonce_bytes = bytes.fromhex(params.nonce)
    salt_bytes = bytes.fromhex(params.salt)
    password = _make_password(nonce_bytes, counter, counter_mode)
    recomputed = derive_key(params, salt_bytes, password)
    recomputed_hex = recomputed.hex()
    key_matches = _constant_time_equal(recomputed_hex, solution.derived_key)
    prefix_matches = recomputed_hex.startswith(params.key_prefix.lower())
    invalid = not (key_matches and prefix_matches)

    return VerifySolutionResult(
        expired=False,
        invalid_signature=False,
        invalid_solution=invalid,
        time=(time.monotonic() - start_time) * 1000,
        verified=not invalid,
    )


# ---------------------------------------------------------------------------
# Server signature verification
# ---------------------------------------------------------------------------

#: Fields whose comma-separated value is automatically split into a list.
_ARRAY_FIELDS = ("fields", "reasons")


class ServerSignaturePayload:
    """
    A server-signed verification payload (as returned by the ALTCHA API).

    Attributes:
        algorithm: HMAC/hash algorithm (e.g. ``'SHA-256'``).
        signature: HMAC signature of the hashed verification data.
        verification_data: URL-encoded query string of verification attributes.
        verified: Whether the server marked the payload as verified.
    """

    def __init__(
        self,
        algorithm: str,
        signature: str,
        verification_data: str,
        verified: bool,
    ):
        self.algorithm = algorithm
        self.signature = signature
        self.verification_data = verification_data
        self.verified = verified

    def to_dict(self) -> dict:
        return {
            "algorithm": self.algorithm,
            "signature": self.signature,
            "verificationData": self.verification_data,
            "verified": self.verified,
        }

    @classmethod
    def from_dict(cls, d: dict) -> ServerSignaturePayload:
        return cls(
            algorithm=d["algorithm"],
            signature=d["signature"],
            verification_data=d["verificationData"],
            verified=bool(d.get("verified", False)),
        )

    @classmethod
    def from_base64(cls, data: str) -> ServerSignaturePayload:
        return cls.from_dict(json.loads(base64.b64decode(data).decode()))


class VerifyServerSignatureResult:
    """
    Result of a server signature verification.

    Attributes:
        expired: ``True`` if the ``expire`` field is in the past.
        invalid_signature: ``True`` if the HMAC signature does not match.
        invalid_solution: ``True`` if ``verified`` is not ``True`` in the payload
            or in the parsed verification data.
        time: Time taken for verification in milliseconds.
        verified: ``True`` if all checks passed.
        verification_data: Parsed key/value data from the verification string,
            or ``None`` if parsing failed.
    """

    def __init__(
        self,
        expired: bool,
        invalid_signature: bool,
        invalid_solution: bool,
        time: float,
        verified: bool,
        verification_data: dict | None,
    ):
        self.expired = expired
        self.invalid_signature = invalid_signature
        self.invalid_solution = invalid_solution
        self.time = time
        self.verified = verified
        self.verification_data = verification_data


def parse_verification_data(
    data: str,
    convert_to_array: tuple[str, ...] = _ARRAY_FIELDS,
) -> dict | None:
    """
    Parse URL-encoded verification data into a typed dict.

    Values are coerced as follows:

    - ``'true'`` / ``'false'`` → ``bool``
    - All-digit strings → ``int``
    - Digit-dot-digit strings → ``float``
    - Keys in *convert_to_array* → ``list[str]`` (comma-split)
    - Everything else → ``str``

    Returns ``None`` if parsing fails.
    """
    try:
        result: dict = {}
        for key, value in urllib.parse.parse_qsl(data):
            if value == "true":
                result[key] = True
            elif value == "false":
                result[key] = False
            elif re.fullmatch(r"\d+", value):
                result[key] = int(value)
            elif re.fullmatch(r"\d+\.\d+", value):
                result[key] = float(value)
            elif key in convert_to_array and value:
                result[key] = [v.strip() for v in value.split(",")]
            else:
                result[key] = value.strip()
        return result
    except (ValueError, TypeError, AttributeError):
        return None


# Digests available to WebCrypto, which altcha-lib uses to hash verificationData.
_SERVER_SIGNATURE_HASHES = frozenset({"sha1", "sha256", "sha384", "sha512"})


def _js_utf8(s: str) -> bytes:
    """UTF-8 encode like JS ``TextEncoder``: lone surrogates become U+FFFD."""
    return (
        s.encode("utf-16-le", "surrogatepass").decode("utf-16-le", "replace").encode()
    )


def verify_server_signature(
    payload: str | ServerSignaturePayload,
    hmac_secret: str | bytes,
    *,
    hmac_algorithm: HmacAlgorithmV2 = DEFAULT_HMAC_ALGORITHM,
) -> VerifyServerSignatureResult:
    """
    Verify an ALTCHA server-signed payload.

    Args:
        payload: Base64-encoded JSON string or a :class:`ServerSignaturePayload` object.
            Its ``algorithm`` (hash of ``verificationData``) must be SHA-1, SHA-256,
            SHA-384 or SHA-512; malformed payloads fail with ``invalid_signature``.
        hmac_secret: Secret used to verify the HMAC signature. Must not be empty.
        hmac_algorithm: HMAC digest algorithm. Defaults to ``'SHA-256'``.

    Returns:
        A :class:`VerifyServerSignatureResult` describing the outcome.

    Raises:
        ValueError: If *hmac_secret* is empty.
    """
    if not hmac_secret:
        raise ValueError("hmac_secret must not be empty")
    start_time = time.monotonic()

    if isinstance(payload, str):
        try:
            p = ServerSignaturePayload.from_base64(payload)
        except (ValueError, KeyError, TypeError, RecursionError):
            return VerifyServerSignatureResult(
                expired=False,
                invalid_signature=True,
                invalid_solution=True,
                time=(time.monotonic() - start_time) * 1000,
                verified=False,
                verification_data=None,
            )
    else:
        p = payload

    # Compute expected signature: HMAC(hash(verificationData), secret)
    hash_name = (
        p.algorithm.lower().replace("-", "") if isinstance(p.algorithm, str) else None
    )
    if hash_name not in _SERVER_SIGNATURE_HASHES or not isinstance(
        p.verification_data, str
    ):
        return VerifyServerSignatureResult(
            expired=False,
            invalid_signature=True,
            invalid_solution=True,
            time=(time.monotonic() - start_time) * 1000,
            verified=False,
            verification_data=None,
        )
    data_hash = hashlib.new(hash_name, _js_utf8(p.verification_data)).digest()
    expected_sig = _hmac_v2(hmac_algorithm, data_hash, hmac_secret).hex()

    verification_data = parse_verification_data(p.verification_data)

    expire = verification_data.get("expire") if verification_data else None
    expired = isinstance(expire, int) and expire < int(time.time())

    invalid_signature = not _constant_time_equal(p.signature, expected_sig)

    invalid_solution = (
        verification_data is None
        or verification_data.get("verified") is not True
        or not p.verified
    )

    verified = not expired and not invalid_signature and not invalid_solution

    return VerifyServerSignatureResult(
        expired=expired,
        invalid_signature=invalid_signature,
        invalid_solution=invalid_solution,
        time=(time.monotonic() - start_time) * 1000,
        verified=verified,
        verification_data=verification_data if verified else None,
    )


# ---------------------------------------------------------------------------
# Remote (Sentinel API) verification
# ---------------------------------------------------------------------------


class VerifyServerResult:
    """
    Result of a remote Sentinel verification via :func:`verify_server`.

    Attributes:
        verified: ``True`` if Sentinel confirmed the payload is valid.
        reason: Failure reason (e.g. an error code or exception message), if any.
        api_key: The API key associated with the payload, if returned.
        verification_data: Parsed verification data, if returned.
    """

    def __init__(
        self,
        verified: bool,
        reason: str | None = None,
        api_key: str | None = None,
        verification_data: dict | None = None,
    ):
        self.verified = verified
        self.reason = reason
        self.api_key = api_key
        self.verification_data = verification_data

    @classmethod
    def from_dict(cls, d: dict) -> VerifyServerResult:
        return cls(
            verified=bool(d.get("verified", False)),
            reason=d.get("reason"),
            api_key=d.get("apiKey"),
            verification_data=d.get("verificationData"),
        )


def _default_http_post(
    url: str, data: bytes, headers: dict[str, str], timeout: float
) -> tuple[int, bytes]:
    """Minimal stdlib HTTP POST, used as the default transport for :func:`verify_server`."""
    req = urllib.request.Request(url, data=data, method="POST", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def _sleep_backoff(attempt: int, delay: float, backoff: str) -> None:
    wait = delay if backoff == "fixed" else delay * (2**attempt)
    time.sleep(wait)


def verify_server(
    payload: str | ServerSignaturePayload | dict,
    url: str,
    secret: str | None = None,
    *,
    headers: dict[str, str] | None = None,
    timeout: float = 10.0,
    retries: int = 0,
    retry_delay: float = 0.3,
    retry_backoff: Literal["fixed", "exponential"] = "exponential",
    http_post: Callable[[str, bytes, dict[str, str], float], tuple[int, bytes]]
    | None = None,
) -> VerifyServerResult:
    """
    Verify a payload remotely via the ALTCHA Sentinel ``/v1/verify/signature`` API.

    Instead of verifying the HMAC signature locally (see :func:`verify_server_signature`),
    this POSTs the payload to Sentinel and trusts its response. Avoids managing the HMAC
    secret on your server, at the cost of a network round-trip.

    Args:
        payload: The payload to verify, as received from ``POST /v1/verify`` — a base64
            string, a :class:`ServerSignaturePayload`, or an already-decoded dict.
        url: Full URL of the Sentinel ``/v1/verify/signature`` endpoint.
        secret: API key secret. If given, Sentinel checks it against the payload's API key.
        headers: Additional headers to send with the request.
        timeout: Per-attempt request timeout in seconds. Defaults to ``10``.
        retries: Number of retry attempts after the first try. Defaults to ``0``.
        retry_delay: Base delay in seconds between retries. Defaults to ``0.3``.
        retry_backoff: ``'fixed'`` or ``'exponential'`` backoff applied to *retry_delay*.
        http_post: Transport override — ``(url, body, headers, timeout) -> (status, body)``.
            Defaults to a stdlib ``urllib.request``-based implementation. Swap in another
            HTTP client (e.g. ``requests``, ``httpx``) here if preferred.

    Returns:
        A :class:`VerifyServerResult` describing the outcome. Failures (HTTP errors, network
        errors, or a negative Sentinel verdict) are reported via ``verified=False`` with a
        ``reason``, never raised as exceptions.
    """
    if isinstance(payload, ServerSignaturePayload):
        payload_value: str | dict = payload.to_dict()
    else:
        payload_value = payload

    body: dict = {"payload": payload_value}
    if secret is not None:
        body["secret"] = secret
    data = json.dumps(body).encode()

    req_headers = {"Content-Type": "application/json", **(headers or {})}
    post = http_post or _default_http_post

    attempts = retries + 1
    for attempt in range(attempts):
        try:
            status, resp_body = post(url, data, req_headers, timeout)
        except Exception as e:  # noqa: BLE001 -- custom transports may raise anything
            if attempt >= attempts - 1:
                return VerifyServerResult(
                    verified=False, reason=str(e) or type(e).__name__
                )
            _sleep_backoff(attempt, retry_delay, retry_backoff)
            continue

        if status == 400:
            try:
                err_data = json.loads(resp_body.decode())
            except ValueError:
                err_data = None
            reason = (err_data or {}).get("error") or f"HTTP_{status}"
            return VerifyServerResult(verified=False, reason=reason)

        if not (200 <= status < 300):
            if attempt >= attempts - 1:
                return VerifyServerResult(verified=False, reason=f"HTTP_{status}")
            _sleep_backoff(attempt, retry_delay, retry_backoff)
            continue

        return VerifyServerResult.from_dict(json.loads(resp_body.decode()))

    return VerifyServerResult(verified=False, reason="NETWORK_ERROR")
